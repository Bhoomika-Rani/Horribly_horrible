'use strict';
// Zero-dependency backend: Node's built-in http + a JSON file. Run: node server/server.js
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const PORT=process.env.PORT||3000,PUB=path.join(__dirname,'..','public'),DB=path.join(__dirname,'data.json');
const DIFFS=['easy','normal','hard'];
let db={sessions:{},scores:[],events:0};
try{db=Object.assign(db,JSON.parse(fs.readFileSync(DB,'utf8')))}catch(e){}
let saveT=null;const save=()=>{clearTimeout(saveT);saveT=setTimeout(()=>fs.writeFile(DB,JSON.stringify(db),()=>{}),300)};
const MIME={'.html':'text/html','.js':'text/javascript','.css':'text/css','.json':'application/json','.png':'image/png','.ico':'image/x-icon'};
const hits=new Map();
function limited(ip){const now=Date.now(),a=(hits.get(ip)||[]).filter(t=>now-t<60000);a.push(now);hits.set(ip,a);return a.length>120}
setInterval(()=>{const now=Date.now();for(const[k,a]of hits)if(!a.some(t=>now-t<60000))hits.delete(k)},60000).unref();
function send(res,code,obj){const b=JSON.stringify(obj);res.writeHead(code,{'Content-Type':'application/json','Access-Control-Allow-Origin':'*','Access-Control-Allow-Methods':'GET,POST,PUT,OPTIONS','Access-Control-Allow-Headers':'Content-Type'});res.end(b)}
const fail=(res,code,msg)=>send(res,code,{ok:false,error:msg});
function body(req){return new Promise((ok,no)=>{let d='';req.on('data',c=>{d+=c;if(d.length>10000){no(new Error('too large'));req.destroy()}});req.on('end',()=>{if(!d)return ok({});try{ok(JSON.parse(d))}catch(e){no(new Error('bad json'))}});req.on('error',no)})}
const clean=s=>String(s||'').replace(/[^\w \-.]/g,'').trim().slice(0,16);
async function api(req,res,u){
 const p=u.pathname,m=req.method;
 if(m==='OPTIONS')return send(res,204,{});
 if(p==='/api/health'&&m==='GET')return send(res,200,{ok:true,time:Date.now(),scores:db.scores.length});
 if(p==='/api/session'&&m==='POST'){const b=await body(req),id=crypto.randomBytes(8).toString('hex');db.sessions[id]={name:clean(b.playerName)||'Player',created:Date.now(),settings:null};save();return send(res,200,{ok:true,sessionId:id})}
 if(p==='/api/scores'&&m==='POST'){
  const b=await body(req),name=clean(b.name)||'Player',score=Number(b.score),t=Number(b.timeSeconds),fl=Number(b.floorReached),df=b.difficulty;
  if(!Number.isFinite(score)||score<0||score>12000)return fail(res,400,'invalid score');
  if(!Number.isFinite(t)||t<15||t>36000)return fail(res,400,'invalid time');
  if(!Number.isInteger(fl)||fl<0||fl>4)return fail(res,400,'invalid floor');
  if(!DIFFS.includes(df))return fail(res,400,'invalid difficulty');
  db.scores.push({name,score:Math.round(score),timeSeconds:Math.round(t),floorReached:fl,difficulty:df,at:Date.now()});
  db.scores.sort((a,b)=>b.score-a.score);db.scores=db.scores.slice(0,500);save();return send(res,201,{ok:true});
 }
 if(p==='/api/scores'&&m==='GET'){const lim=Math.min(50,Math.max(1,parseInt(u.searchParams.get('limit'))||10)),df=u.searchParams.get('difficulty');
  return send(res,200,{ok:true,scores:db.scores.filter(s=>!df||s.difficulty===df).slice(0,lim).map(s=>({name:s.name,score:s.score,timeSeconds:s.timeSeconds,difficulty:s.difficulty}))})}
 let mm=p.match(/^\/api\/settings\/([a-f0-9]{16})$/);
 if(mm){const s=db.sessions[mm[1]];if(!s)return fail(res,404,'unknown session');
  if(m==='GET')return send(res,200,{ok:true,settings:s.settings});
  if(m==='PUT'){const b=await body(req),o={};
   if(typeof b.volume==='number')o.volume=Math.min(1,Math.max(0,b.volume));
   if(typeof b.sens==='number')o.sens=Math.min(1,Math.max(0,b.sens));
   if(typeof b.ai==='number')o.ai=Math.min(1,Math.max(0,b.ai));
   if(DIFFS.includes(b.diff))o.diff=b.diff;
   if(['low','medium','high'].includes(b.quality))o.quality=b.quality;
   s.settings=o;save();return send(res,200,{ok:true,settings:o})}}
 if(p==='/api/events'&&m==='POST'){await body(req);db.events++;save();return send(res,202,{ok:true})}
 return fail(res,404,'not found');
}
function serveStatic(req,res,u){
 let f=path.normalize(decodeURIComponent(u.pathname));if(f==='/'||f==='\\')f='/index.html';
 const fp=path.join(PUB,f);if(!fp.startsWith(PUB))return fail(res,403,'forbidden');
 fs.readFile(fp,(e,d)=>{if(e)return fail(res,404,'not found');res.writeHead(200,{'Content-Type':MIME[path.extname(fp)]||'application/octet-stream','Cache-Control':'no-cache'});res.end(d)});
}
const server=http.createServer(async(req,res)=>{
 try{
  const ip=req.socket.remoteAddress||'?';if(limited(ip))return fail(res,429,'too many requests');
  const u=new URL(req.url,'http://x');
  if(u.pathname.startsWith('/api/'))await api(req,res,u);else serveStatic(req,res,u);
 }catch(e){if(!res.headersSent)fail(res,e.message==='bad json'||e.message==='too large'?400:500,e.message||'server error');else res.end()}
});
if(require.main===module)server.listen(PORT,()=>console.log('Horribly Horrible running on http://localhost:'+PORT));
module.exports=server;
