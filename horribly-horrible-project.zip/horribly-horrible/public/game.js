'use strict';
/* ===== HORRIBLY HORRIBLE — The Cursed Haveli (self-contained canvas 3D engine) ===== */
const $=id=>document.getElementById(id), R=Math.random, TAU=Math.PI*2;
const clamp=(v,a,b)=>v<a?a:v>b?b:v;
const CFG={volume:.7,quality:'medium',sens:.5,diff:'normal',ai:.7,fps:false};
const DIFF={easy:{sp:1.3,sight:8,hear:5,dmg:8,stam:.6},normal:{sp:1.8,sight:11,hear:7,dmg:14,stam:1},hard:{sp:2.4,sight:14,hear:9,dmg:22,stam:1.4}};
const QW={low:320,medium:480,high:640};
try{const s=JSON.parse(localStorage.getItem('hh_cfg')||'{}');Object.assign(CFG,s)}catch(e){}
function saveCfg(){try{localStorage.setItem('hh_cfg',JSON.stringify(CFG))}catch(e){}if((typeof API!=='undefined'))API.saveSettings(CFG)}
function mulberry(a){return function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
function mk(w,h,fn){const c=document.createElement('canvas');c.width=w;c.height=h;fn(c.getContext('2d'),w,h);return c}

/* ---------- Audio (synthesized) ---------- */
const Snd=(()=>{
 let ctx,out,nb,hbT=null,hbRate=0,windOn=false;
 function init(){
  try{
   if(!ctx){ctx=new(window.AudioContext||window.webkitAudioContext)();out=ctx.createGain();out.gain.value=CFG.volume;out.connect(ctx.destination)}
   if(ctx.state==='suspended')ctx.resume();
  }catch(e){ctx=null}
 }
 function buf(){if(nb)return nb;nb=ctx.createBuffer(1,ctx.sampleRate*2,ctx.sampleRate);const d=nb.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=R()*2-1;return nb}
 function tone(type,f1,f2,dur,g,t0){
  if(!ctx)return;const t=ctx.currentTime+(t0||0),o=ctx.createOscillator(),G=ctx.createGain();
  o.type=type;o.frequency.setValueAtTime(f1,t);if(f2)o.frequency.exponentialRampToValueAtTime(f2,t+dur);
  G.gain.setValueAtTime(.0001,t);G.gain.linearRampToValueAtTime(g,t+.02);G.gain.exponentialRampToValueAtTime(.001,t+dur);
  o.connect(G);G.connect(out);o.start(t);o.stop(t+dur+.05);
 }
 function noise(dur,f,q,g,type){
  if(!ctx)return;const s=ctx.createBufferSource(),F=ctx.createBiquadFilter(),G=ctx.createGain(),t=ctx.currentTime;
  s.buffer=buf();F.type=type||'lowpass';F.frequency.value=f;F.Q.value=q;
  G.gain.setValueAtTime(0,t);G.gain.linearRampToValueAtTime(g,t+.05);G.gain.linearRampToValueAtTime(0,t+dur);
  s.connect(F);F.connect(G);G.connect(out);s.start();s.stop(t+dur+.1);
 }
 function beat(){tone('sine',55,40,.25,.5);setTimeout(()=>tone('sine',45,35,.2,.35),180)}
 return{init,
  vol(v){CFG.volume=v;if(out)out.gain.value=v},
  heart(rate){rate=Math.round(rate*4)/4;if(rate===hbRate)return;hbRate=rate;clearInterval(hbT);hbT=null;if(rate>.1&&ctx){beat();hbT=setInterval(beat,1000/rate)}},
  wind(){
   if(!ctx||windOn)return;windOn=true;
   const s=ctx.createBufferSource(),f=ctx.createBiquadFilter(),g=ctx.createGain(),l=ctx.createOscillator(),lg=ctx.createGain();
   s.buffer=buf();s.loop=true;f.type='bandpass';f.frequency.value=400;f.Q.value=.6;g.gain.value=.08;
   l.frequency.value=.15;lg.gain.value=200;l.connect(lg);lg.connect(f.frequency);s.connect(f);f.connect(g);g.connect(out);s.start();l.start();
   const d=ctx.createGain();d.gain.value=.05;d.connect(out);[55,57].forEach(fr=>{const o=ctx.createOscillator();o.frequency.value=fr;o.connect(d);o.start()});
  },
  scream(){tone('sawtooth',800,400,1.1,.4);tone('square',1800,500,.6,.15);noise(1.1,2000,1,.3)},
  whisper(){noise(1.5,1500,8,.15,'bandpass')},
  thunder(){noise(2.5,120,.8,.5);setTimeout(()=>noise(.3,3000,1,.3),50)},
  creak(){tone('sawtooth',80,220,.9,.15)},
  cackle(){for(let i=0;i<5;i++)tone('sawtooth',400+R()*200,900,.1,.15,i*.12)},
  laugh(){for(let i=0;i<6;i++)tone('sine',900+R()*300,0,.08,.08,i*.1)},
  step(){noise(.15,300,1,.12)},
  win(){[523,659,784,1046].forEach((f,i)=>tone('triangle',f,0,.8,.2,i*.2))},
  die(){tone('sawtooth',200,40,1.5,.3)},
  hit(){tone('square',150,60,.25,.3);noise(.2,800,1,.25)}
 };
})();
/* ---------- Procedural art ---------- */
const TEX={},SPR={};
function stains(c,w,h,rnd,n,col){c.fillStyle=col;for(let i=0;i<n;i++){const x=rnd()*w,y=rnd()*h*.6,l=6+rnd()*(h*.5);c.globalAlpha=.25+rnd()*.35;c.fillRect(x,y,1+rnd()*2,l);c.beginPath();c.arc(x+.5,y+l,1.5+rnd()*2,0,TAU);c.fill()}c.globalAlpha=1}
function speckle(c,w,h,rnd,n){for(let i=0;i<n;i++){c.fillStyle=rnd()>.5?'rgba(0,0,0,.18)':'rgba(255,255,255,.05)';c.fillRect(rnd()*w|0,rnd()*h|0,1+(rnd()*2|0),1+(rnd()*2|0))}}
function buildTextures(){
 let r=mulberry(7);
 TEX.stone=mk(64,64,(c,w,h)=>{c.fillStyle='#3c3c38';c.fillRect(0,0,w,h);c.strokeStyle='#1d1d1a';c.lineWidth=2;for(let y=0;y<h;y+=16){c.beginPath();c.moveTo(0,y);c.lineTo(w,y);c.stroke();for(let x=(y/16%2)*16;x<w;x+=32){c.beginPath();c.moveTo(x,y);c.lineTo(x,y+16);c.stroke()}}speckle(c,w,h,r,160);c.fillStyle='rgba(30,60,20,.25)';c.fillRect(0,h-10,w,10)});
 const facade=(win)=>mk(64,64,(c,w,h)=>{
  const g=c.createLinearGradient(0,0,0,h);g.addColorStop(0,'#6a5640');g.addColorStop(1,'#4a3a2a');c.fillStyle=g;c.fillRect(0,0,w,h);
  c.fillStyle='#2e2218';c.fillRect(0,0,w,5);c.fillRect(0,h-6,w,6);c.fillRect(0,0,4,h);c.fillRect(w-4,0,4,h);
  c.fillStyle='#7d664a';for(let i=0;i<4;i++)c.fillRect(8+i*14,6,6,4);
  if(win){c.fillStyle='#2a1c10';c.beginPath();c.moveTo(14,56);c.lineTo(14,24);c.arc(32,24,18,Math.PI,0);c.lineTo(50,56);c.fill();
   const gg=c.createLinearGradient(0,14,0,56);gg.addColorStop(0,'#ffcf6a');gg.addColorStop(1,'#c4601a');c.fillStyle=gg;c.beginPath();c.moveTo(18,56);c.lineTo(18,25);c.arc(32,25,14,Math.PI,0);c.lineTo(46,56);c.fill();
   c.fillStyle='#1a0f08';c.fillRect(31,12,2,44);c.fillRect(18,36,28,2);c.fillRect(12,52,40,6)}
  else{c.fillStyle='#3a2c1e';c.beginPath();c.moveTo(20,56);c.lineTo(20,28);c.arc(32,28,12,Math.PI,0);c.lineTo(44,56);c.fill();c.fillStyle='#52402c';c.fillRect(22,30,20,24)}
  speckle(c,w,h,r,120);stains(c,w,h,r,3,'#2a0a05')});
 TEX.facW=facade(true);TEX.facP=facade(false);
 TEX.door=mk(64,64,(c,w,h)=>{c.fillStyle='#4a3a2a';c.fillRect(0,0,w,h);c.fillStyle='#1d120a';c.beginPath();c.moveTo(6,64);c.lineTo(6,22);c.arc(32,22,26,Math.PI,0);c.lineTo(58,64);c.fill();
  const g=c.createLinearGradient(0,0,0,64);g.addColorStop(0,'#5a3418');g.addColorStop(1,'#2b1707');c.fillStyle=g;c.beginPath();c.moveTo(10,64);c.lineTo(10,23);c.arc(32,23,22,Math.PI,0);c.lineTo(54,64);c.fill();
  c.fillStyle='#ff2a0a';c.globalAlpha=.55;c.fillRect(31,6,2,58);c.globalAlpha=1;c.fillStyle='#9a8a5a';for(let y=14;y<62;y+=10){c.fillRect(16,y,3,3);c.fillRect(45,y,3,3)}c.fillStyle='#c9a64a';c.fillRect(26,36,3,3);c.fillRect(35,36,3,3)});
 const wp=(base,pat,seed)=>mk(64,64,(c,w,h)=>{const rr=mulberry(seed);c.fillStyle=base;c.fillRect(0,0,w,h);c.strokeStyle=pat;c.globalAlpha=.35;c.lineWidth=1;for(let x=0;x<w;x+=16){c.beginPath();c.moveTo(x+8,0);c.lineTo(x+8,h);c.stroke();for(let y=8;y<h;y+=16){c.beginPath();c.arc(x+8,y,3,0,TAU);c.stroke()}}c.globalAlpha=1;c.fillStyle='rgba(0,0,0,.35)';c.fillRect(0,h-8,w,8);c.fillStyle='rgba(0,0,0,.25)';c.fillRect(0,0,w,4);speckle(c,w,h,rr,140);stains(c,w,h,rr,4,'#4a0000')});
 TEX.w1=wp('#4a3424','#8a6a3a',11);TEX.w2=wp('#3a1a1a','#8a2a2a',12);TEX.w3=wp('#232a38','#5a6a8a',13);TEX.w4=wp('#201010','#6a1a1a',14);
 TEX.up=mk(64,64,(c,w,h)=>{c.fillStyle='#2a2a28';c.fillRect(0,0,w,h);for(let i=0;i<8;i++){c.fillStyle=`rgb(${60+i*12},${55+i*10},${48+i*8})`;c.fillRect(8+i*2,56-i*6,48-i*4,6)}c.fillStyle='#ffd77a';c.globalAlpha=.8;c.beginPath();c.moveTo(32,4);c.lineTo(46,18);c.lineTo(38,18);c.lineTo(38,28);c.lineTo(26,28);c.lineTo(26,18);c.lineTo(18,18);c.fill();c.globalAlpha=1});
 TEX.lock=mk(64,64,(c,w,h)=>{c.fillStyle='#3a2410';c.fillRect(0,0,w,h);for(let x=0;x<w;x+=16){c.fillStyle=x%32?'#4a2e14':'#35200d';c.fillRect(x,0,15,h)}c.fillStyle='#777';c.fillRect(0,18,w,5);c.fillRect(0,42,w,5);c.fillStyle='#caa43a';c.fillRect(26,26,12,14);c.strokeStyle='#caa43a';c.lineWidth=3;c.beginPath();c.arc(32,26,6,Math.PI,0);c.stroke();c.fillStyle='#000';c.fillRect(31,31,2,5)});
 TEX.panel=mk(64,64,(c,w,h)=>{c.drawImage(TEX.w4,0,0);c.fillStyle='#120808';c.fillRect(14,10,36,44);c.strokeStyle='#8a1a1a';c.lineWidth=2;c.strokeRect(14,10,36,44);c.fillStyle='#ff3a2a';c.globalAlpha=.6;c.beginPath();c.arc(32,32,6,0,TAU);c.fill();c.globalAlpha=1});
 TEX.win=mk(64,64,(c,w,h)=>{c.drawImage(TEX.w4,0,0);const g=c.createLinearGradient(0,0,0,64);g.addColorStop(0,'#1a2a4a');g.addColorStop(1,'#0a0f1c');c.fillStyle=g;c.fillRect(12,8,40,48);c.fillStyle='#eee8c8';c.beginPath();c.arc(40,22,5,0,TAU);c.fill();c.strokeStyle='#050505';c.lineWidth=3;c.strokeRect(12,8,40,48);c.beginPath();c.moveTo(32,8);c.lineTo(32,56);c.moveTo(12,32);c.lineTo(52,32);c.stroke()});
 TEX.plank=mk(64,64,(c,w,h)=>{c.drawImage(TEX.w4,0,0);c.fillStyle='#4a2e14';for(let y=6;y<h;y+=18){c.fillRect(2,y,60,11);c.fillStyle='#2a1a0a';c.fillRect(2,y+9,60,2);c.fillStyle='#4a2e14'}c.fillStyle='#aaa';[[8,10],[56,10],[8,28],[56,28],[8,46],[56,46]].forEach(p=>c.fillRect(p[0],p[1],3,3))});
}
/* ---------- the witch: pointed crooked hat, messy hair, dirty torn dress ---------- */
function witchBody(c,w,h,fx){ // full-body sprite on a w x h canvas
 const r=mulberry(99),cx=w/2;
 c.save();c.translate(0,fx?0:0);
 // dress (dirty, torn)
 const dg=c.createLinearGradient(0,h*.35,0,h);dg.addColorStop(0,'#2b2530');dg.addColorStop(1,'#14100f');
 c.fillStyle=dg;c.beginPath();c.moveTo(cx-w*.12,h*.36);c.lineTo(cx+w*.12,h*.36);c.lineTo(cx+w*.36,h*.97);
 for(let i=0;i<9;i++){c.lineTo(cx+w*.36-i*(w*.72/9)-w*.04,h*(.97+(i%2?.0:-.07)))}
 c.lineTo(cx-w*.36,h*.97);c.closePath();c.fill();
 c.fillStyle='rgba(60,45,20,.5)';for(let i=0;i<14;i++){c.beginPath();c.ellipse(cx+(r()-.5)*w*.55,h*(.5+r()*.45),2+r()*5,3+r()*7,0,0,TAU);c.fill()}
 c.fillStyle='rgba(70,0,0,.55)';for(let i=0;i<6;i++){c.beginPath();c.ellipse(cx+(r()-.5)*w*.4,h*(.55+r()*.4),2+r()*3,3+r()*8,0,0,TAU);c.fill()}
 c.strokeStyle='#0b0808';c.lineWidth=1.5;for(let i=0;i<8;i++){c.beginPath();c.moveTo(cx+(r()-.5)*w*.5,h*.55);c.lineTo(cx+(r()-.5)*w*.7,h*.95);c.stroke()}
 // arms + claws
 c.strokeStyle='#4b4640';c.lineWidth=w*.045;c.lineCap='round';
 c.beginPath();c.moveTo(cx-w*.1,h*.4);c.quadraticCurveTo(cx-w*.3,h*.52,cx-w*.26,h*.66);c.stroke();
 c.beginPath();c.moveTo(cx+w*.1,h*.4);c.quadraticCurveTo(cx+w*.3,h*.5,cx+w*.28,h*.64);c.stroke();
 c.strokeStyle='#8c8678';c.lineWidth=1.5;[[-.26,.66],[.28,.64]].forEach(p=>{for(let k=-2;k<=2;k++){c.beginPath();c.moveTo(cx+w*p[0],h*p[1]);c.lineTo(cx+w*p[0]+k*w*.03,h*(p[1]+.09));c.stroke()}});
 // messy hair behind head
 c.strokeStyle='#1c1b1d';for(let i=0;i<46;i++){c.lineWidth=1+r()*2.2;const a=Math.PI*(.15+r()*.7)+Math.PI/2*0,sx=cx+(r()-.5)*w*.1,sy=h*.2;
  c.beginPath();c.moveTo(sx,sy);const ex=cx+(r()-.5)*w*.62,ey=h*(.3+r()*.4);c.bezierCurveTo(cx+(r()-.5)*w*.5,h*.12,ex+(r()-.5)*w*.2,h*(.25+r()*.2),ex,ey);c.stroke()}
 c.strokeStyle='#6b6a6e';c.lineWidth=1;for(let i=0;i<14;i++){const sx=cx+(r()-.5)*w*.1;c.beginPath();c.moveTo(sx,h*.2);c.bezierCurveTo(cx+(r()-.5)*w*.5,h*.14,cx+(r()-.5)*w*.6,h*.3,cx+(r()-.5)*w*.55,h*(.35+r()*.2));c.stroke()}
 // face
 const fg=c.createRadialGradient(cx,h*.22,2,cx,h*.22,w*.14);fg.addColorStop(0,'#a8b0a0');fg.addColorStop(1,'#5a6458');
 c.fillStyle=fg;c.beginPath();c.ellipse(cx,h*.225,w*.105,h*.075,0,0,TAU);c.fill();
 c.fillStyle='#7a8272';c.beginPath();c.moveTo(cx-2,h*.215);c.lineTo(cx+w*.035,h*.26);c.lineTo(cx-w*.005,h*.255);c.closePath();c.fill(); // hooked nose
 c.fillStyle='#ffe34a';c.shadowColor='#ff3300';c.shadowBlur=8;c.beginPath();c.ellipse(cx-w*.04,h*.2,w*.022,h*.011,-.3,0,TAU);c.ellipse(cx+w*.04,h*.2,w*.022,h*.011,.3,0,TAU);c.fill();c.shadowBlur=0;
 c.fillStyle='#000';c.fillRect(cx-w*.04-1,h*.196,2,h*.008);c.fillRect(cx+w*.04-1,h*.196,2,h*.008);
 c.fillStyle='#1a0505';c.beginPath();c.ellipse(cx,h*.275,w*.05,h*.012,0,0,TAU);c.fill();
 c.fillStyle='#d8d2a0';for(let i=-3;i<=3;i++)c.fillRect(cx+i*w*.012-1,h*.268,2,h*.01);
 c.strokeStyle='#2a2f28';c.lineWidth=1;for(let i=0;i<5;i++){c.beginPath();c.moveTo(cx-w*.09+r()*w*.18,h*.17);c.lineTo(cx-w*.09+r()*w*.18,h*.28);c.stroke()}
 // hat: crooked, tattered
 c.fillStyle='#17101a';c.beginPath();c.ellipse(cx,h*.15,w*.24,h*.028,-.08,0,TAU);c.fill();
 c.beginPath();c.moveTo(cx-w*.13,h*.15);c.quadraticCurveTo(cx-w*.05,h*.07,cx+w*.12,h*.0);c.quadraticCurveTo(cx+w*.13,-h*.01,cx+w*.21,h*.04);c.quadraticCurveTo(cx+w*.1,h*.07,cx+w*.13,h*.15);c.closePath();c.fill();
 c.fillStyle='#4a1d3a';c.fillRect(cx-w*.12,h*.12,w*.25,h*.016);
 c.strokeStyle='#0a060b';c.lineWidth=1;for(let i=0;i<5;i++){c.beginPath();c.moveTo(cx-w*.2+i*w*.1,h*.15);c.lineTo(cx-w*.19+i*w*.1,h*.175);c.stroke()}
 c.restore();
}
function buildSprites(){
 SPR.witch=mk(160,256,(c,w,h)=>witchBody(c,w,h));
 SPR.ghost=mk(96,160,(c,w,h)=>{const g=c.createLinearGradient(0,0,0,h);g.addColorStop(0,'rgba(220,225,255,.85)');g.addColorStop(1,'rgba(180,190,230,.05)');c.fillStyle=g;c.beginPath();c.moveTo(w*.2,h*.9);c.lineTo(w*.2,h*.3);c.quadraticCurveTo(w*.5,-h*.02,w*.8,h*.3);c.lineTo(w*.8,h*.9);for(let i=0;i<6;i++)c.lineTo(w*.8-i*w*.1-w*.05,h*(i%2?.88:1));c.closePath();c.fill();c.fillStyle='#04040c';c.beginPath();c.ellipse(w*.38,h*.32,6,10,0,0,TAU);c.ellipse(w*.62,h*.32,6,10,0,0,TAU);c.fill();c.beginPath();c.ellipse(w*.5,h*.5,7,12,0,0,TAU);c.fill()});
 SPR.zombie=mk(96,160,(c,w,h)=>{const r=mulberry(5);c.fillStyle='#2a3322';c.fillRect(w*.3,h*.36,w*.4,h*.4);c.fillStyle='#22301c';c.fillRect(w*.32,h*.74,w*.13,h*.26);c.fillRect(w*.55,h*.74,w*.13,h*.26);
  c.fillStyle='#6b7d58';c.beginPath();c.arc(w*.5,h*.22,w*.15,0,TAU);c.fill();c.fillStyle='#d9d27a';c.beginPath();c.arc(w*.44,h*.2,3,0,TAU);c.arc(w*.56,h*.2,3,0,TAU);c.fill();c.fillStyle='#2a0a0a';c.fillRect(w*.42,h*.28,w*.16,4);
  c.strokeStyle='#6b7d58';c.lineWidth=7;c.lineCap='round';c.beginPath();c.moveTo(w*.3,h*.4);c.lineTo(w*.1,h*.5);c.moveTo(w*.7,h*.4);c.lineTo(w*.9,h*.5);c.stroke();stains(c,w,h,r,6,'#4a0000')});
 SPR.grave=mk(64,96,(c,w,h)=>{c.fillStyle='#4a4a48';c.beginPath();c.moveTo(10,96);c.lineTo(10,30);c.arc(32,30,22,Math.PI,0);c.lineTo(54,96);c.fill();c.fillStyle='#2a2a28';c.fillRect(30,34,4,22);c.fillRect(24,40,16,4);c.fillStyle='rgba(30,70,20,.5)';c.fillRect(10,80,44,16)});
 SPR.tree=mk(128,192,(c,w,h)=>{const r=mulberry(3);c.strokeStyle='#150f0a';c.lineCap='round';c.lineWidth=12;c.beginPath();c.moveTo(64,192);c.lineTo(62,100);c.stroke();function br(x,y,a,l,d,lw){if(d===0)return;const nx=x+Math.cos(a)*l,ny=y+Math.sin(a)*l;c.lineWidth=lw;c.beginPath();c.moveTo(x,y);c.lineTo(nx,ny);c.stroke();br(nx,ny,a-.5-r()*.3,l*.72,d-1,lw*.7);br(nx,ny,a+.5+r()*.3,l*.72,d-1,lw*.7)}br(62,100,-Math.PI/2,34,5,8)});
 SPR.drawer=mk(64,64,(c,w,h)=>{c.fillStyle='#4a2e14';c.fillRect(6,22,52,38);c.fillStyle='#2a1a0a';c.fillRect(8,26,48,13);c.fillRect(8,42,48,15);c.fillStyle='#caa43a';c.fillRect(28,31,8,3);c.fillRect(28,48,8,3)});
 SPR.closet=mk(64,128,(c,w,h)=>{c.fillStyle='#3a2410';c.fillRect(6,6,52,120);c.fillStyle='#2a1808';c.fillRect(10,10,21,112);c.fillRect(33,10,21,112);c.fillStyle='#caa43a';c.fillRect(27,64,3,8);c.fillRect(34,64,3,8)});
 SPR.book=mk(64,64,(c,w,h)=>{c.fillStyle='#3a2410';c.fillRect(14,40,36,22);c.fillStyle='#8b0000';c.shadowColor='#ff2200';c.shadowBlur=14;c.fillRect(18,26,28,16);c.shadowBlur=0;c.fillStyle='#d9b24a';c.fillRect(20,28,24,2);c.fillRect(30,32,4,6)});
 SPR.crow=mk(48,32,(c,w,h)=>{c.fillStyle='#050505';c.beginPath();c.ellipse(24,18,8,5,0,0,TAU);c.fill();c.beginPath();c.moveTo(24,16);c.lineTo(4,6);c.lineTo(14,18);c.moveTo(24,16);c.lineTo(44,6);c.lineTo(34,18);c.fill()});
}
function drawWitchBust(c,w,h){ // jump-scare close-up of the real witch
 c.fillStyle='#000';c.fillRect(0,0,w,h);
 const bg=c.createRadialGradient(w/2,h*.4,10,w/2,h*.4,w*.7);bg.addColorStop(0,'#3a0a0a');bg.addColorStop(1,'#000');c.fillStyle=bg;c.fillRect(0,0,w,h);
 const r=mulberry(Math.floor(R()*9999)),cx=w/2;
 // wild hair
 for(let i=0;i<150;i++){c.strokeStyle=i%6?'#16151a':'#77767c';c.lineWidth=1+r()*4;const sx=cx+(r()-.5)*w*.3,sy=h*.2+r()*h*.1;c.beginPath();c.moveTo(sx,sy);c.bezierCurveTo(cx+(r()-.5)*w*1.1,h*.05+r()*h*.3,cx+(r()-.5)*w*1.2,h*.35+r()*h*.3,cx+(r()-.5)*w*1.0,h*(.55+r()*.45));c.stroke()}
 // hat
 c.fillStyle='#120b16';c.beginPath();c.moveTo(cx-w*.5,h*.27);c.quadraticCurveTo(cx-w*.2,h*.2,cx-w*.25,h*.17);c.quadraticCurveTo(cx-w*.1,h*.05,cx+w*.3,-h*.02);c.quadraticCurveTo(cx+w*.2,h*.1,cx+w*.28,h*.17);c.quadraticCurveTo(cx+w*.3,h*.2,cx+w*.52,h*.28);c.quadraticCurveTo(cx,h*.33,cx-w*.5,h*.27);c.fill();
 c.fillStyle='#4a1d3a';c.fillRect(cx-w*.25,h*.17,w*.5,h*.025);c.strokeStyle='#050206';c.lineWidth=2;for(let i=0;i<14;i++){c.beginPath();c.moveTo(cx-w*.5+i*w*.075,h*.3);c.lineTo(cx-w*.5+i*w*.075+r()*8,h*.3+10+r()*20);c.stroke()}
 // face
 const fg=c.createRadialGradient(cx,h*.45,10,cx,h*.45,w*.3);fg.addColorStop(0,'#b9c2b0');fg.addColorStop(1,'#55604e');c.fillStyle=fg;c.beginPath();c.ellipse(cx,h*.46,w*.24,h*.19,0,0,TAU);c.fill();
 c.strokeStyle='#2a3128';c.lineWidth=2;for(let i=0;i<22;i++){c.beginPath();const x=cx-w*.2+r()*w*.4;c.moveTo(x,h*.3+r()*h*.1);c.quadraticCurveTo(x+r()*20-10,h*.45,x+r()*30-15,h*.55+r()*h*.1);c.stroke()}
 c.fillStyle='#7a8470';c.beginPath();c.moveTo(cx-6,h*.43);c.quadraticCurveTo(cx+w*.1,h*.52,cx+w*.04,h*.56);c.lineTo(cx-8,h*.54);c.fill();
 c.shadowColor='#ff3300';c.shadowBlur=30;c.fillStyle='#ffee44';c.beginPath();c.ellipse(cx-w*.09,h*.4,w*.05,h*.022,-.3,0,TAU);c.ellipse(cx+w*.09,h*.4,w*.05,h*.022,.3,0,TAU);c.fill();c.shadowBlur=0;
 c.fillStyle='#000';c.fillRect(cx-w*.09-3,h*.388,6,h*.026);c.fillRect(cx+w*.09-3,h*.388,6,h*.026);
 c.fillStyle='#120202';c.beginPath();c.ellipse(cx,h*.62,w*.13,h*.055,0,0,TAU);c.fill();
 c.fillStyle='#d9d29a';for(let i=-5;i<=5;i++){c.beginPath();c.moveTo(cx+i*w*.022-5,h*.585);c.lineTo(cx+i*w*.022,h*.585+20+r()*14);c.lineTo(cx+i*w*.022+5,h*.585);c.fill()}
 // dirty ragged dress / shoulders
 const dg=c.createLinearGradient(0,h*.7,0,h);dg.addColorStop(0,'#2a232e');dg.addColorStop(1,'#0c0909');c.fillStyle=dg;c.beginPath();c.moveTo(cx-w*.45,h);c.lineTo(cx-w*.3,h*.74);c.quadraticCurveTo(cx,h*.68,cx+w*.3,h*.74);c.lineTo(cx+w*.45,h);for(let i=0;i<10;i++)c.lineTo(cx+w*.45-i*(w*.9/10)-w*.04,h*(i%2?.95:1));c.closePath();c.fill();
 c.fillStyle='rgba(60,45,20,.55)';for(let i=0;i<20;i++){c.beginPath();c.ellipse(cx+(r()-.5)*w*.7,h*(.78+r()*.2),4+r()*10,6+r()*14,0,0,TAU);c.fill()}
 c.fillStyle='rgba(90,0,0,.6)';for(let i=0;i<8;i++){c.beginPath();c.ellipse(cx+(r()-.5)*w*.6,h*(.8+r()*.18),3+r()*5,8+r()*18,0,0,TAU);c.fill()}
 // claw hands
 c.strokeStyle='#8c8678';c.lineWidth=5;c.lineCap='round';[-1,1].forEach(s=>{for(let k=0;k<5;k++){c.beginPath();c.moveTo(cx+s*w*.3,h*.9);c.quadraticCurveTo(cx+s*(w*.34+k*8),h*.78,cx+s*(w*.3+k*14),h*.7-k*4);c.stroke()}});
}
/* ---------- Levels ---------- */
const OPEN='#...................#';
const LEVELS=[
 {name:'Courtyard',obj:'Walk to the haveli door and enter',out:true,
  map:['#####################','#HHHHHHHHHEHHHHHHHHH#',OPEN,OPEN,OPEN,OPEN,OPEN,OPEN,OPEN,OPEN,OPEN,OPEN,OPEN,OPEN,'#####################'],
  ents:[],items:[],
  decor:[['grave',3.5,4.5],['grave',6.5,6.5],['grave',2.5,8.5],['grave',16.5,4.5],['grave',14.5,7.5],['grave',18.5,9.5],['tree',3.5,11.2],['tree',17.5,11.2],['tree',1.8,3.2],['tree',19,3.2],['grave',5.5,10.5],['grave',15.5,11.5]]},
 {name:'Ground Floor',obj:'Escape the witches and find the stairs',
  map:['#################U###','#...................#','#...##.........##...#','#...##.........##...#','#...................#','#.......#####.......#','#...................#','#...##.........##...#','#...##.........##...#',OPEN,OPEN,OPEN,OPEN,OPEN,'#####################'],
  ents:[['witch',2.5,2.5],['witch',18.5,3.5],['witch',10.5,7.5]],items:[],decor:[]},
 {name:'First Floor',obj:'Find the rusty key in the drawer and unlock the door',
  map:['##########U##########','##########.##########','##########.##########','##########L##########',OPEN,OPEN,'#.....###.....###...#',OPEN,OPEN,'#...###.........#...#',OPEN,OPEN,OPEN,OPEN,'#####################'],
  ents:[['witch',4.5,5.5],['witch',16.5,8.5]],items:[{t:'key',x:3.5,y:12.5,label:'Search drawer'}],decor:[]},
 {name:'Second Floor',obj:'Ghosts haunt this floor. Reach the stairs (hide in the closet if needed)',
  map:['###U#################',OPEN,OPEN,'#.....##.....##.....#',OPEN,OPEN,'#.......###.........#',OPEN,OPEN,'#...##.........##...#',OPEN,OPEN,OPEN,OPEN,'#####################'],
  ents:[['ghost',8.5,2.5],['ghost',16.5,6.5],['ghost',2.5,9.5],['ghost',12.5,11.5]],items:[{t:'closet',x:18.5,y:5.5,label:'Hide in closet'}],decor:[]},
 {name:'The Top Floor',obj:'Take the Treasure Book and hide it in the secret panel',
  map:['###P#################',OPEN,OPEN,OPEN,'w...................#','#...##.......##.....#',OPEN,'w...................#',OPEN,OPEN,'w...................#',OPEN,OPEN,OPEN,'#####################'],
  ents:[['zombie',8.5,3.5],['zombie',14.5,7.5],['zombie',5.5,10.5]],items:[{t:'book',x:16.5,y:2.5,label:'Take the Treasure Book'}],decor:[]}
];
const SOLID='#HEULPwB';
const SPR_H={witch:1.0,ghost:.9,zombie:.95,grave:.7,tree:1.6,drawer:.45,closet:.95,book:.35,crow:.2};
let map=[],lvl=0;
function loadMap(n){map=LEVELS[n].map.map(r=>r.split(''))}
function tileAt(x,y){const r=map[y|0];return r?(r[x|0]||'#'):'#'}
function solidAt(x,y){return SOLID.indexOf(tileAt(x,y))>=0}
function blocked(x,y,r){return solidAt(x-r,y-r)||solidAt(x+r,y-r)||solidAt(x-r,y+r)||solidAt(x+r,y+r)}
function los(ax,ay,bx,by){const d=Math.hypot(bx-ax,by-ay),n=Math.ceil(d/.3);for(let i=1;i<n;i++){const t=i/n;if(solidAt(ax+(bx-ax)*t,ay+(by-ay)*t))return false}return true}
function texFor(ch,mx,my){
 switch(ch){case'#':return lvl===0?TEX.stone:TEX['w'+lvl];case'H':return(mx&1)?TEX.facW:TEX.facP;case'E':return TEX.door;case'U':return TEX.up;
  case'L':return TEX.lock;case'P':return TEX.panel;case'w':return TEX.win;case'B':return TEX.plank}return TEX.stone}

/* ---------- Renderer ---------- */
const cv=$('gl'),cx=cv.getContext('2d',{alpha:false});
let W=480,H=270,zb=new Float32Array(480),shadeCache=[];
const PLANE=.66;
function resize(){
 W=QW[CFG.quality]||480;H=Math.max(120,Math.round(W*innerHeight/Math.max(1,innerWidth)));
 cv.width=W;cv.height=H;zb=new Float32Array(W);
 shadeCache=[];for(let i=0;i<=24;i++)shadeCache.push('rgba(4,2,6,'+(i/24).toFixed(3)+')');
}
addEventListener('resize',resize);
function skyBackdrop(horizon,yaw){
 const g=cx.createLinearGradient(0,0,0,horizon);g.addColorStop(0,'#04060f');g.addColorStop(1,'#1a2036');cx.fillStyle=g;cx.fillRect(0,0,W,horizon);
 const fov=2*Math.atan(PLANE),ang=a=>{let d=a-yaw;while(d>Math.PI)d-=TAU;while(d<-Math.PI)d+=TAU;return W/2+d/fov*W};
 cx.fillStyle='#cfd2bc';for(let i=0;i<40;i++){const a=i*2.399,x=ang(a*3.1),y=(i*37%100)/100*horizon*.7;cx.fillRect(x,y,1,1)}
 const mx=ang(-2.3);cx.fillStyle='#e8e6c8';cx.shadowColor='#aab';cx.shadowBlur=12;cx.beginPath();cx.arc(mx,horizon*.25,H*.05,0,TAU);cx.fill();cx.shadowBlur=0;
 // haveli skyline silhouette (north)
 const base=horizon,u=W/14,c0=ang(-Math.PI/2);cx.fillStyle='#07060a';
 const rect=(x,w,h)=>cx.fillRect(c0+x*u,base-h*u,w*u,h*u+2);
 rect(-6,12,1.2);rect(-6.5,1.6,3.4);rect(4.9,1.6,3.4);rect(-2.2,4.4,2.6);rect(-1.1,2.2,3.2);
 const dome=(x,y,r)=>{cx.beginPath();cx.arc(c0+x*u,base-y*u,r*u,Math.PI,0);cx.fill();cx.fillRect(c0+(x-.06)*u,base-(y+r+.7)*u,.12*u,.7*u)};
 dome(-5.7,3.4,.8);dome(6.1,3.4,.8);dome(0,4.6,1.4);dome(-3.3,2.5,.6);dome(3.3,2.5,.6);
 cx.fillStyle='#ffb347';[[-5.7,2.2],[6.1,2.2],[-.4,3.2],[.4,3.2],[0,2.2]].forEach(p=>cx.fillRect(c0+p[0]*u,base-p[1]*u,2,3));
 const gg=cx.createLinearGradient(0,horizon,0,H);gg.addColorStop(0,'#1a2216');gg.addColorStop(1,'#050805');cx.fillStyle=gg;cx.fillRect(0,horizon,W,H-horizon);
}
function render(P,ents,time){
 const horizon=(H/2+Math.sin(P.bob)*1.6)|0,dirX=Math.cos(P.yaw),dirY=Math.sin(P.yaw),plX=-dirY*PLANE,plY=dirX*PLANE;
 const out=LEVELS[lvl].out,focal=W/(2*PLANE),flOn=P.fl&&P.bat>0;
 if(out)skyBackdrop(horizon,P.yaw);
 else{
  const cg=cx.createLinearGradient(0,0,0,horizon);cg.addColorStop(0,'#030203');cg.addColorStop(1,'#120b09');cx.fillStyle=cg;cx.fillRect(0,0,W,horizon);
  const fg=cx.createLinearGradient(0,horizon,0,H);fg.addColorStop(0,'#0a0605');fg.addColorStop(1,'#2a1a10');cx.fillStyle=fg;cx.fillRect(0,horizon,W,H-horizon);
 }
 const flick=.94+Math.sin(time*13)*.03+(R()<.01?-.25:0),amb=out?.42:.27;
 for(let x=0;x<W;x++){
  const camX=2*x/W-1,rx=dirX+plX*camX,ry=dirY+plY*camX;
  let mx=P.x|0,my=P.y|0;const ddx=Math.abs(1/(rx||1e-9)),ddy=Math.abs(1/(ry||1e-9));
  let sx,sy,sdx,sdy;
  if(rx<0){sx=-1;sdx=(P.x-mx)*ddx}else{sx=1;sdx=(mx+1-P.x)*ddx}
  if(ry<0){sy=-1;sdy=(P.y-my)*ddy}else{sy=1;sdy=(my+1-P.y)*ddy}
  let side=0,hit=false,ch='#',guard=0;
  while(!hit&&guard++<64){if(sdx<sdy){sdx+=ddx;mx+=sx;side=0}else{sdy+=ddy;my+=sy;side=1}
   const rr=map[my];ch=rr?rr[mx]:'#';if(ch===undefined)ch='#';if(SOLID.indexOf(ch)>=0)hit=true}
  let dist=side===0?(mx-P.x+(1-sx)/2)/(rx||1e-9):(my-P.y+(1-sy)/2)/(ry||1e-9);if(dist<.05)dist=.05;
  zb[x]=dist;
  let wx=side===0?P.y+dist*ry:P.x+dist*rx;wx-=Math.floor(wx);
  let tx=(wx*64)|0;if(side===0&&rx>0)tx=63-tx;if(side===1&&ry<0)tx=63-tx;
  const lh=focal/dist,bottom=horizon+lh*.5,tex=texFor(ch,mx,my);
  if(out&&ch==='#'){const hh=lh*.55;cx.drawImage(tex,tx,64*.45,1,64*.55,x,bottom-hh,1,hh)}
  else if(out&&ch==='H'){cx.drawImage(tex,tx,0,1,64,x,bottom-lh,1,lh+1);cx.drawImage(tex,tx,0,1,64,x,bottom-lh*2,1,lh+1)}
  else if(out&&ch==='E'){cx.drawImage(tex,tx,0,1,64,x,bottom-lh,1,lh+1);cx.drawImage(TEX.facW,tx,0,1,64,x,bottom-lh*2,1,lh+1)}
  else cx.drawImage(tex,tx,0,1,64,x,bottom-lh,1,lh+1);
  let a=(dist/(out?16:10.5))*(1-amb)+(1-amb)*.35;if(side)a+=.1;
  if(flOn){const cone=Math.max(0,1-Math.abs(x-W/2)/(W*.3));a*=1-.62*cone*Math.max(0,1-dist/16)}
  a=clamp(a/flick,out?.05:.1,.96);
  const top=(out&&ch==='#')?bottom-lh*.55:(out&&(ch==='H'||ch==='E'))?bottom-lh*2:bottom-lh;
  cx.fillStyle=shadeCache[(a*24)|0];cx.fillRect(x,top,1,bottom-top+1);
 }
 // sprites
 const sp=[];
 for(const e of ents){if(e.vis===false)continue;const dx=e.x-P.x,dy=e.y-P.y;sp.push({s:e,d:dx*dx+dy*dy,dx,dy})}
 sp.sort((a,b)=>b.d-a.d);
 const inv=1/(plX*dirY-dirX*plY);
 for(const q of sp){
  const e=q.s,tx2=inv*(dirY*q.dx-dirX*q.dy),ty=inv*(-plY*q.dx+plX*q.dy);if(ty<.2||ty>22)continue;
  const img=SPR[e.spr],hh=(SPR_H[e.spr]||1),size=focal/ty*hh,wd=size*img.width/img.height,scx=(W/2)*(1+tx2/ty);
  const lift=(e.lift||0)*focal/ty,bottom=horizon+focal/ty*.5-lift,x0=Math.floor(scx-wd/2),x1=Math.floor(scx+wd/2);
  let al=clamp(1-ty/(out?18:10),.12,1);if(flOn){const cone=Math.max(0,1-Math.abs(scx-W/2)/(W*.3));al=clamp(al+cone*.5,.12,1)}
  if(e.alpha)al*=e.alpha;
  for(let x=Math.max(0,x0);x<=Math.min(W-1,x1);x++){
   if(ty>=zb[x])continue;const sxp=((x-x0)/(x1-x0+1)*img.width)|0;
   cx.globalAlpha=al;cx.drawImage(img,sxp,0,1,img.height,x,bottom-size,1,size);
  }
 }
 cx.globalAlpha=1;
 if(flOn){const g=cx.createRadialGradient(W/2,H*.5,4,W/2,H*.5,W*.38);g.addColorStop(0,'rgba(255,240,190,.13)');g.addColorStop(1,'rgba(255,240,190,0)');cx.globalCompositeOperation='lighter';cx.fillStyle=g;cx.fillRect(0,0,W,H);cx.globalCompositeOperation='source-over'}
}
/* ---------- State ---------- */
const P={x:10.5,y:12.5,yaw:-Math.PI/2,bob:0,hp:100,stam:100,bat:100,fl:true,hiding:false,key:false,book:false,noise:0};
const S={state:'load',t0:0,dmg:0,hides:0,items:0,scares:0,tcd:0,cd:0,stepT:0,winning:false,extraT:40,blocked:0};
let enemies=[],items=[],decor=[],run=false,useFlag=false,lastFrame=0,fps=60,fpsAcc=0,fpsN=0,fpsT=0;
const OV=['title','settings','intro','pause','over','win'];
const show=id=>$(id).classList.remove('hidden'),hide=id=>$(id).classList.add('hidden');
function showOnly(id){OV.forEach(o=>hide(o));if(id)show(id)}
let hintT;function hint(s,ms){const h=$('hint');h.textContent=s;h.classList.add('on');clearTimeout(hintT);hintT=setTimeout(()=>h.classList.remove('on'),ms||2800)}
const setObj=s=>$('obj').textContent=s;
const setSlot=(i,c)=>$('s'+i).textContent=c;

/* ---------- AI Director ---------- */
const Dir={m:{},mod:1,tension:.5,last:0,cd:15,
 reset(){this.m={dmg:0,time:0};this.mod=1;this.tension=.5;this.last=0;this.cd=15},
 update(dt,hp,dists){
  this.m.time+=dt;const avg=dists.length?dists.reduce((a,b)=>a+b,0)/dists.length:20;
  this.tension+=(Math.max(0,1-avg/16)-this.tension)*Math.min(1,dt*1.2);
  if(hp>80&&this.m.time>60)this.mod=Math.min(1.5,this.mod+.001*dt);else if(hp<30)this.mod=Math.max(.6,this.mod-.002*dt);
  this.last+=dt;return this.last>this.cd&&this.tension>.55&&R()<.25*CFG.ai*dt;
 },
 scared(){this.last=0;this.cd=14+R()*20}
};
/* ---------- Spawning ---------- */
const ESPR={witch:'witch',ghost:'ghost',zombie:'zombie'};
function mkEnemy(type,x,y){
 const d=DIFF[CFG.diff];
 return{type,spr:ESPR[type],x,y,sp:type==='witch'?d.sp:type==='ghost'?1.1:d.sp*.65,alert:0,last:null,timer:0,flank:null,flanked:false,told:new Set(),cd:0,vis:true,ph:R()*6,visT:2+R()*3,patrol:null,cack:3+R()*5,alpha:type==='ghost'?.75:1,lift:type==='ghost'?.12:0,id:Math.random()};
}
function freeSpot(minD){for(let i=0;i<60;i++){const x=1.5+R()*18,y=1.5+R()*12;if(!solidAt(x,y)&&Math.hypot(x-P.x,y-P.y)>minD)return[x,y]}return null}
function loadLevel(n){
 lvl=n;loadMap(n);const L=LEVELS[n];
 P.x=10.5;P.y=12.5;P.yaw=-Math.PI/2;P.hiding=false;S.tcd=1.2;S.winning=false;S.extraT=40;
 enemies=[];const base=L.ents,cnt=base.length?Math.max(1,Math.round(base.length*Dir.mod)):0;
 for(let i=0;i<cnt;i++){const b=base[i%base.length];let x=b[1],y=b[2];if(i>=base.length){const s=freeSpot(7);if(s){x=s[0];y=s[1]}}enemies.push(mkEnemy(b[0],x,y))}
 items=L.items.map(it=>({t:it.t,x:it.x,y:it.y,label:it.label,taken:false,spr:it.t==='key'?'drawer':it.t==='closet'?'closet':'book'}));
 if(n===4&&P.book)items.forEach(i=>{if(i.t==='book')i.taken=true});
 decor=L.decor.map(d=>({spr:d[0],x:d[1],y:d[2]}));
 if(n===0)for(let i=0;i<4;i++)decor.push({spr:'crow',x:2+R()*17,y:2.5+R()*5,lift:.9+R()*.4});
 setObj(L.obj);
 if(n===2)hint('Floor 2: a witch lurks here. Find the key in the drawer.');
 if(n===3){hint('Ghosts... they fade in and out. Keep moving.');Snd.laugh()}
 if(n===4)hint('The top floor. The Treasure Book is here...');
 if(n===1)Snd.creak();
}
/* ---------- Game flow ---------- */
function newRun(){
 Object.assign(P,{hp:100,stam:100,bat:100,fl:true,hiding:false,key:false,book:false,noise:0,bob:0});
 Object.assign(S,{dmg:0,hides:0,items:0,scares:0,winning:false,t0:performance.now()});
 Dir.reset();setSlot(0,'');setSlot(1,'');loadLevel(0);
}
function toTitle(){
 Snd.heart(0);document.exitPointerLock&&document.exitPointerLock();
 showOnly('title');hide('hud');hide('touch');S.state='title';newRun();
}
function beginPlay(){
 showOnly(null);show('hud');if(isTouch())show('touch');S.state='play';S.t0=performance.now();Snd.init();Snd.wind();Snd.heart(.75);
 if(!isTouch()&&cv.requestPointerLock)try{cv.requestPointerLock()}catch(e){}
}
const isTouch=()=>('ontouchstart' in window)||navigator.maxTouchPoints>0&&matchMedia('(pointer:coarse)').matches;
function startFlow(){
 Snd.init();
 try{const el=document.documentElement;if(!document.fullscreenElement&&el.requestFullscreen)el.requestFullscreen().then(()=>{try{screen.orientation.lock('landscape').catch(()=>{})}catch(e){}}).catch(()=>{})}catch(e){}
 try{screen.orientation&&screen.orientation.lock&&screen.orientation.lock('landscape').catch(()=>{})}catch(e){}
 newRun();showOnly('intro');S.state='intro';
 if((typeof API!=='undefined'))API.session('Player');
 setTimeout(()=>{if(S.state==='intro')witchScare()},1300);
}
function togglePause(){
 if(S.state==='play'){S.state='pause';showOnly('pause');Snd.heart(0);document.exitPointerLock&&document.exitPointerLock()}
 else if(S.state==='pause'){S.state='play';showOnly(null);Snd.heart(.75);if(!isTouch()&&cv.requestPointerLock)try{cv.requestPointerLock()}catch(e){}}
}
function damage(a){
 if(P.hiding||S.state!=='play'||S.winning)return;
 P.hp=Math.max(0,P.hp-a);S.dmg++;Snd.hit();Dir.m.dmg++;
 document.body.classList.add('shake');setTimeout(()=>document.body.classList.remove('shake'),300);
 if(P.hp<=0)gameOver();
}
function gameOver(){
 if(S.state==='over')return;S.state='over';Snd.heart(0);Snd.die();document.exitPointerLock&&document.exitPointerLock();hide('hud');hide('touch');
 $('oStats').innerHTML='Time survived: '+((performance.now()-S.t0)/1000).toFixed(1)+'s<br>Floor reached: '+lvl+'<br>Hits taken: '+S.dmg;
 showOnly('over');
}
function calcScore(){return Math.max(0,Math.round(10000-((performance.now()-S.t0)/1000)*8-S.dmg*150+P.hp*10))}
function victory(){
 if(S.state==='over'||S.state==='win')return;S.state='win';Snd.heart(0);Snd.win();document.exitPointerLock&&document.exitPointerLock();hide('hud');hide('touch');
 const sc=calcScore(),t=(performance.now()-S.t0)/1000;
 $('wStats').innerHTML='Time: '+t.toFixed(1)+'s<br>Score: <b style="color:gold">'+sc+'</b><br>The haveli is at peace.<div id="board" style="margin-top:8px;font-size:12px;color:#aaa">Saving score...</div>';
 showOnly('win');
 if((typeof API!=='undefined'))API.submitScore({name:'Player',score:sc,timeSeconds:Math.round(t),floorReached:lvl,difficulty:CFG.diff}).then(r=>{
  const b=$('board');if(!b)return;b.innerHTML='<b>Top scores</b>'+(r.offline?' <i>(saved on this device)</i>':'')+'<br>'+r.list.map((s,i)=>(i+1)+'. '+String(s.name).slice(0,12)+' — '+s.score).join('<br>')});
}
let scT;
function witchScare(){
 const sc=$('scare');drawWitchBust($('witchC').getContext('2d'),600,800);sc.classList.add('on');Snd.scream();S.scares++;Dir.scared();
 const c=$('witchC');c.style.animation='none';void c.offsetWidth;c.style.animation='';
 clearTimeout(scT);scT=setTimeout(()=>sc.classList.remove('on'),950);
}
/* ---------- Interaction ---------- */
function facing(){return[Math.cos(P.yaw),Math.sin(P.yaw)]}
function goUp(){
 if(S.tcd>0)return;S.tcd=1.2;
 if(lvl>=4)return;loadLevel(lvl+1);Snd.creak();
}
function tryUse(){
 if(S.state!=='play'||S.winning)return;
 const[fx,fy]=facing();
 if(P.hiding){P.hiding=false;hint('You step out.');return}
 let best=null,bd=1.7;
 for(const it of items){if(it.taken)continue;const dx=it.x-P.x,dy=it.y-P.y,d=Math.hypot(dx,dy);if(d<bd&&(dx*fx+dy*fy)/(d||1)>.25){best=it;bd=d}}
 if(best){
  if(best.t==='key'){if(!P.key){P.key=true;S.items++;setSlot(0,'🗝');hint('You found a rusty key!');Snd.creak();best.taken=true}}
  else if(best.t==='closet'){P.hiding=true;S.hides++;hint('Hiding... press USE to step out.');Snd.creak()}
  else if(best.t==='book'){P.book=true;best.taken=true;S.items++;setSlot(1,'📕');setObj('Hide the book in the secret panel (north wall)');hint('You took the TREASURE BOOK!');Snd.whisper()}
  return;
 }
 for(const t of[.55,.9,1.3]){
  const tx=Math.floor(P.x+fx*t),ty=Math.floor(P.y+fy*t),ch=tileAt(tx,ty);
  if(ch==='L'){if(P.key){map[ty][tx]='.';hint('Door unlocked!');Snd.creak()}else hint('Locked. You need a key.');return}
  if(ch==='P'){if(P.book){S.winning=true;hint('The book vanishes into the wall... the curse breaks!');Snd.win();setTimeout(victory,1800)}else hint('A loose panel in the wall... you have nothing to hide here.');return}
  if(ch==='w'){map[ty][tx]='B';hint('Window boarded up.');Snd.creak();return}
  if(ch==='E'||ch==='U'){goUp();return}
 }
}
function autoStairs(){
 if(S.tcd>0)return;
 const cx0=P.x|0,cy0=P.y|0;
 for(let oy=-1;oy<=1;oy++)for(let ox=-1;ox<=1;ox++){const ch=tileAt(cx0+ox,cy0+oy);
  if((ch==='E'||ch==='U')&&Math.hypot(cx0+ox+.5-P.x,cy0+oy+.5-P.y)<1.05){goUp();return}}
}
/* ---------- Enemy AI ---------- */
function moveEnt(e,tx,ty,sp,dt,ghost){
 const dx=tx-e.x,dy=ty-e.y,d=Math.hypot(dx,dy);if(d<.05)return true;
 const mx=dx/d*sp*dt,my=dy/d*sp*dt;
 if(ghost){e.x+=mx;e.y+=my}else{if(!blocked(e.x+mx,e.y,.2))e.x+=mx;if(!blocked(e.x,e.y+my,.2))e.y+=my}
 return d<.4;
}
function updateEnemy(e,dt){
 const d=DIFF[CFG.diff],dist=Math.hypot(P.x-e.x,P.y-e.y);e.cd=Math.max(0,e.cd-dt);
 if(e.type==='ghost'){
  e.ph+=dt;e.lift=.12+Math.sin(e.ph*2)*.05;e.visT-=dt;
  if(e.visT<=0){e.vis=!e.vis;e.visT=1.5+R()*3;if(e.vis&&R()<.5)Snd.whisper()}
  if(P.hiding){moveEnt(e,e.x+Math.cos(e.ph)*3,e.y+Math.sin(e.ph*1.3)*3,e.sp*.4,dt,true);return}
  if(dist<12)moveEnt(e,P.x,P.y,e.sp,dt,true);else moveEnt(e,e.x+Math.cos(e.ph),e.y+Math.sin(e.ph),e.sp*.3,dt,true);
  if(e.vis&&dist<.85&&e.cd<=0){damage(10+(CFG.diff==='hard'?6:0));e.cd=1.8;Snd.laugh()}
  return;
 }
 const sight=e.type==='witch'?d.sight:d.sight*.8,hear=d.hear*(.3+P.noise*1.4);
 const sees=!P.hiding&&dist<sight&&los(e.x,e.y,P.x,P.y),heard=!P.hiding&&P.noise>0&&dist<hear;
 if(sees){e.alert=2;e.last={x:P.x,y:P.y};e.timer=5;
  for(const o of enemies){if(o===e||o.type==='ghost'||e.told.has(o.id)||Math.hypot(o.x-e.x,o.y-e.y)>12)continue;if(o.alert<2){o.alert=Math.max(o.alert,1);o.last={x:P.x,y:P.y};o.timer=4}e.told.add(o.id)}
 }else if(heard){e.alert=Math.max(e.alert,1);e.last={x:P.x,y:P.y};e.timer=3}
 else{e.timer-=dt;if(e.timer<=0){e.alert=0;e.last=null;e.flank=null;e.flanked=false;e.told.clear()}}
 if(P.hiding&&e.alert===2){e.alert=1;e.timer=2}
 if(e.alert===2&&!e.flanked&&dist>4&&R()<.6*CFG.ai*dt){
  e.flanked=true;const a=Math.atan2(P.y-e.y,P.x-e.x)+(R()>.5?1:-1)*Math.PI/3,fx=P.x+Math.cos(a)*4,fy=P.y+Math.sin(a)*4;
  if(!solidAt(fx,fy))e.flank={x:fx,y:fy};
 }
 if(e.type==='witch'){e.cack-=dt;if(e.cack<=0&&e.alert>0&&dist<14){Snd.cackle();e.cack=5+R()*7}}
 if(e.alert===2){
  let tx=P.x,ty=P.y;if(e.flank&&dist>3){tx=e.flank.x;ty=e.flank.y;if(Math.hypot(tx-e.x,ty-e.y)<.8)e.flank=null}
  moveEnt(e,tx,ty,e.sp*1.15,dt);
  if(dist<.95&&e.cd<=0){damage(d.dmg);e.cd=1.3;if(e.type==='witch')Snd.scream()}
 }else if(e.alert===1&&e.last){moveEnt(e,e.last.x,e.last.y,e.sp*.75,dt)}
 else{
  if(!e.patrol||Math.hypot(e.patrol.x-e.x,e.patrol.y-e.y)<.5||R()<.003){const a=R()*TAU,r=2+R()*4,px=e.x+Math.cos(a)*r,py=e.y+Math.sin(a)*r;e.patrol=solidAt(px,py)?null:{x:px,y:py}}
  if(e.patrol)moveEnt(e,e.patrol.x,e.patrol.y,e.sp*.4,dt);
 }
}
/* ---------- Player + frame ---------- */
const keys={},joy={x:0,y:0};let lookDX=0;
function updatePlay(dt){
 let mx=(keys.KeyD||keys.ArrowRight?1:0)-(keys.KeyA||keys.ArrowLeft?1:0),mz=(keys.KeyW||keys.ArrowUp?1:0)-(keys.KeyS||keys.ArrowDown?1:0);
 mx+=joy.x;mz+=-joy.y;const len=Math.hypot(mx,mz);if(len>1){mx/=len;mz/=len}
 if(keys.ArrowLeft&&!keys.KeyA)P.yaw-=1.9*dt;if(keys.ArrowRight&&!keys.KeyD)P.yaw+=1.9*dt;
 const d=DIFF[CFG.diff],moving=len>.08&&!P.hiding&&!S.winning,wantRun=(run||keys.ShiftLeft||keys.ShiftRight)&&moving&&P.stam>4;
 if(wantRun)P.stam=Math.max(0,P.stam-22*d.stam*dt);else P.stam=Math.min(100,P.stam+12*dt);
 const sp=wantRun?3.5:2.2;
 if(moving){
  const fx=Math.cos(P.yaw),fy=Math.sin(P.yaw),rx=-fy,ry=fx,vx=(fx*mz+rx*mx)*sp*dt,vy=(fy*mz+ry*mx)*sp*dt;
  if(!blocked(P.x+vx,P.y,.22))P.x+=vx;if(!blocked(P.x,P.y+vy,.22))P.y+=vy;
  P.bob+=dt*(wantRun?12:7);S.stepT-=dt;if(S.stepT<=0){Snd.step();S.stepT=wantRun?.3:.5}
 }
 P.noise=moving?(wantRun?1:.55):0;
 if(P.fl&&P.bat>0)P.bat=Math.max(0,P.bat-.5*dt);else if(!P.fl)P.bat=Math.min(100,P.bat+1*dt);
 if(useFlag){useFlag=false;tryUse()}
 S.tcd=Math.max(0,S.tcd-dt);autoStairs();
 let minD=99;const dists=[];
 for(const e of enemies){updateEnemy(e,dt);if(e.vis){const dd=Math.hypot(P.x-e.x,P.y-e.y);dists.push(dd);if(dd<minD)minD=dd}}
 const fear=clamp(1-minD/6,0,1);$('fear').style.opacity=P.hiding?0:fear*.85;
 Snd.heart(fear>.25?1+fear*2:.75);
 document.body.classList.toggle('shake',fear>.8);
 if(lvl>0&&Dir.update(dt,P.hp,dists)){if(R()<.35&&lvl>=1)witchScare();else{Snd.whisper();hint('You hear whispers...',2000);Dir.scared()}}
 S.extraT-=dt;if(S.extraT<=0){S.extraT=45;const L=LEVELS[lvl];if(L.ents.length&&P.hp>70&&Dir.tension<.5&&enemies.length<L.ents.length+2){const s=freeSpot(8);if(s)enemies.push(mkEnemy(L.ents[0][0],s[0],s[1]))}}
 hud();
}
let hv=[-1,-1,-1];
function hud(){
 const a=[P.hp|0,P.stam|0,P.bat|0],ids=['hb','sb','bb'];
 for(let i=0;i<3;i++)if(a[i]!==hv[i]){hv[i]=a[i];$(ids[i]).firstChild.style.width=a[i]+'%'}
}
function frame(t){
 requestAnimationFrame(frame);
 const dt=Math.min(.05,(t-lastFrame)/1000||0);lastFrame=t;
 if(S.state==='load'||document.hidden)return;
 const portrait=matchMedia('(orientation:portrait) and (pointer:coarse)').matches;
 if(S.state==='play'&&!portrait)updatePlay(dt);
 else if(S.state==='play'&&portrait){/* paused until rotated */}
 else if(S.state==='title'||S.state==='intro'){P.yaw=-Math.PI/2+Math.sin(t/3000)*.25;P.bob+=dt*1.5;for(const d of decor)if(d.spr==='crow')d.lift+=Math.sin(t/400+d.x)*.002}
 const list=enemies.concat(items.filter(i=>!i.taken),decor);
 render(P,list,t/1000);
 if(P.hiding&&S.state==='play'){cx.fillStyle='rgba(0,0,0,.93)';cx.fillRect(0,0,W,H);cx.clearRect(0,H*.45,W,H*.06);cx.fillStyle='rgba(0,0,0,.55)';cx.fillRect(0,H*.45,W,H*.06)}
 // fps + auto quality
 fpsAcc+=dt;fpsN++;fpsT+=dt;
 if(fpsT>=3){fps=fpsN/fpsAcc;fpsAcc=fpsN=fpsT=0;if(CFG.fps)$('fpsEl').textContent=fps.toFixed(0)+' fps';
  if(fps<38&&S.state==='play'&&CFG.quality!=='low'){CFG.quality=CFG.quality==='high'?'medium':'low';resize();hint('Quality lowered for smoother play',2000)}}
}
/* ---------- Input + wiring ---------- */
addEventListener('keydown',e=>{
 if(e.code==='Escape'){togglePause();return}
 keys[e.code]=true;
 if(e.code==='KeyE'&&!e.repeat)useFlag=true;
 if(e.code==='KeyF'&&!e.repeat&&S.state==='play')P.fl=!P.fl;
 if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Space'].includes(e.code))e.preventDefault();
});
addEventListener('keyup',e=>keys[e.code]=false);
addEventListener('blur',()=>{for(const k in keys)keys[k]=false;run=false;joy.x=joy.y=0});
document.addEventListener('contextmenu',e=>e.preventDefault());
const mouseK=()=>.0015+CFG.sens*.003,touchK=()=>.003+CFG.sens*.007;
let lookId=-1,lx=0;
cv.addEventListener('pointerdown',e=>{
 Snd.init();
 if(e.pointerType==='touch'){if(lookId===-1&&e.clientX>innerWidth*.3){lookId=e.pointerId;lx=e.clientX;try{cv.setPointerCapture(e.pointerId)}catch(_){}}}
 else if(S.state==='play'&&!document.pointerLockElement&&cv.requestPointerLock){try{cv.requestPointerLock()}catch(_){}}
});
cv.addEventListener('pointermove',e=>{
 if(S.state!=='play')return;
 if(e.pointerType==='touch'){if(e.pointerId===lookId){P.yaw+=(e.clientX-lx)*touchK();lx=e.clientX}}
 else if(document.pointerLockElement===cv)P.yaw+=e.movementX*mouseK();
 else if(e.buttons&1)P.yaw+=e.movementX*mouseK();
});
const endLook=e=>{if(e.pointerId===lookId)lookId=-1};
cv.addEventListener('pointerup',endLook);cv.addEventListener('pointercancel',endLook);
document.addEventListener('pointerlockchange',()=>{if(!document.pointerLockElement&&S.state==='play'&&!S.winning)togglePause()});
// joystick
(function(){
 const j=$('joy'),k=$('knob');let id=-1,cx0=0,cy0=0;
 const upd=e=>{let dx=e.clientX-cx0,dy=e.clientY-cy0;const d=Math.hypot(dx,dy);if(d>46){dx*=46/d;dy*=46/d}k.style.transform='translate('+dx+'px,'+dy+'px)';joy.x=dx/46;joy.y=dy/46};
 j.addEventListener('pointerdown',e=>{e.preventDefault();Snd.init();id=e.pointerId;const r=j.getBoundingClientRect();cx0=r.left+r.width/2;cy0=r.top+r.height/2;try{j.setPointerCapture(id)}catch(_){}upd(e)});
 j.addEventListener('pointermove',e=>{if(e.pointerId===id)upd(e)});
 const end=e=>{if(e.pointerId!==id)return;id=-1;joy.x=joy.y=0;k.style.transform='none'};
 j.addEventListener('pointerup',end);j.addEventListener('pointercancel',end);j.addEventListener('lostpointercapture',end);
})();
// action buttons
const press=(id,fn)=>$(id).addEventListener('pointerdown',e=>{e.preventDefault();Snd.init();fn()});
press('bUse',()=>{useFlag=true});
press('bFl',()=>{if(S.state==='play')P.fl=!P.fl});
press('bPause',togglePause);
(function(){const b=$('bRun'),on=e=>{e.preventDefault();run=true},off=()=>{run=false};b.addEventListener('pointerdown',on);['pointerup','pointercancel','pointerleave'].forEach(n=>b.addEventListener(n,off))})();
// menu buttons (click works for mouse + touch)
const on=(id,fn)=>$(id).addEventListener('click',e=>{e.preventDefault();Snd.init();fn()});
let settingsFrom='title';
on('bStart',startFlow);
on('bSet',()=>{settingsFrom='title';showOnly('settings')});
on('bSetBack',()=>{showOnly(settingsFrom);if(settingsFrom==='pause'){show('pause')}});
on('bGo',beginPlay);
on('bRes',togglePause);
on('bPSet',()=>{settingsFrom='pause';showOnly('settings')});
on('bQuit',toTitle);
on('bRetry',()=>{newRun();beginPlay()});
on('bOQuit',toTitle);
on('bAgain',()=>{newRun();beginPlay()});
on('bWQuit',toTitle);
// settings
const bindSet=(id,fn)=>{const el=$(id);el.addEventListener('input',()=>{fn(el.value);saveCfg()});el.addEventListener('change',()=>{fn(el.value);saveCfg()})};
bindSet('sVol',v=>{Snd.vol(v/100)});
bindSet('sSens',v=>{CFG.sens=v/100});
bindSet('sAI',v=>{CFG.ai=v/100});
bindSet('sDiff',v=>{CFG.diff=v});
bindSet('sQ',v=>{CFG.quality=v;resize()});
function syncSettings(){$('sVol').value=Math.round(CFG.volume*100);$('sSens').value=Math.round(CFG.sens*100);$('sAI').value=Math.round(CFG.ai*100);$('sDiff').value=CFG.diff;$('sQ').value=CFG.quality}
document.addEventListener('visibilitychange',()=>{if(document.hidden&&S.state==='play')togglePause()});
/* ---------- Boot ---------- */
function boot(){
 try{
  const fpsEl=document.createElement('div');fpsEl.id='fpsEl';fpsEl.style.cssText='position:absolute;left:14px;top:60px;font-size:10px;color:#8f8;z-index:6';document.body.appendChild(fpsEl);
  if(!CFG.fps)fpsEl.style.display='none';
  const net=document.createElement('div');net.id='net';net.style.cssText='position:absolute;right:12px;bottom:8px;font-size:11px;color:#888;z-index:11';$('title').appendChild(net);
  if((typeof API!=='undefined')){API.health().then(ok=>{net.textContent=ok?'● Online (scores sync)':'○ Offline (scores saved on this device)';net.style.color=ok?'#7c7':'#a77'});
   API.loadSettings().then(s=>{if(s){Object.assign(CFG,s);syncSettings();resize()}})}
  if(/Android|iPhone|iPad|iPod/i.test(navigator.userAgent)&&CFG.quality==='high')CFG.quality='medium';
  syncSettings();buildTextures();buildSprites();resize();newRun();
  hide('load');showOnly('title');S.state='title';
  setTimeout(()=>{if(S.state==='title'){witchScare()}},5500);
  setInterval(()=>{if((S.state==='title'||S.state==='play')&&R()<.3)Snd.thunder()},16000);
 }catch(err){console.error(err);$('load').innerHTML='<div style="color:#f66;padding:20px;text-align:center">Failed to start:<br>'+String(err.message||err)+'<br><br><button class="btn" onclick="location.reload()">Reload</button></div>'}
}
window.addEventListener('error',e=>{if(S.state==='load'){const l=$('load');if(l)l.innerHTML='<div style="color:#f66;padding:20px;text-align:center">Error: '+String(e.message)+'<br><br><button class="btn" onclick="location.reload()">Reload</button></div>'}});
requestAnimationFrame(frame);
if(document.readyState==='complete')boot();else addEventListener('load',boot);
window.__hh={P,S,get lvl(){return lvl},get map(){return map},get enemies(){return enemies},get items(){return items},loadLevel,tryUse,goUp,beginPlay,startFlow,newRun,damage,victory,CFG};
