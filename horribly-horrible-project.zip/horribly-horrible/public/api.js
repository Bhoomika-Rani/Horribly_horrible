/* API client: every call has a timeout and a local fallback, so the game never waits on the network */
const API=(()=>{
 const base='',sess={id:null};
 const getLS=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))||d}catch(e){return d}};
 const setLS=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}};
 async function call(method,path,body){
  const ctl=new AbortController(),t=setTimeout(()=>ctl.abort(),4000);
  try{
   const r=await fetch(base+path,{method,headers:{'Content-Type':'application/json'},body:body?JSON.stringify(body):undefined,signal:ctl.signal});
   if(!r.ok)throw new Error('HTTP '+r.status);return await r.json();
  }finally{clearTimeout(t)}
 }
 const top=l=>l.sort((a,b)=>b.score-a.score).slice(0,10);
 return{
  async health(){try{const r=await call('GET','/api/health');return !!(r&&r.ok)}catch(e){return false}},
  async session(name){try{const r=await call('POST','/api/session',{playerName:name});sess.id=r.sessionId;setLS('hh_sid',sess.id)}catch(e){sess.id=getLS('hh_sid',null)}return sess.id},
  async submitScore(s){
   const local=getLS('hh_scores',[]);local.push({name:s.name,score:s.score,timeSeconds:s.timeSeconds,difficulty:s.difficulty});setLS('hh_scores',top(local));
   try{
    await call('POST','/api/scores',Object.assign({sessionId:sess.id,pending:false},s));
    const r=await call('GET','/api/scores?limit=10&difficulty='+encodeURIComponent(s.difficulty));
    return{list:r.scores,offline:false};
   }catch(e){return{list:top(getLS('hh_scores',[])),offline:true}}
  },
  async saveSettings(cfg){if(!sess.id)return;try{await call('PUT','/api/settings/'+sess.id,cfg)}catch(e){}},
  async loadSettings(){try{const id=sess.id||getLS('hh_sid',null);if(!id)return null;const r=await call('GET','/api/settings/'+id);return r.settings||null}catch(e){return null}}
 };
})();
