# Horribly Horrible — The Cursed Haveli
Run: `npm start` (no dependencies), then open http://localhost:3000 — play in landscape.
Backend: /api/health, /api/session, /api/scores (GET/POST), /api/settings/:id (GET/PUT), /api/events. If the server is offline the game still works and keeps scores on the device.
